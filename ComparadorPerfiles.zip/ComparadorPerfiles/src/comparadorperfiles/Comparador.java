package comparadorperfiles;

import com.fazecast.jSerialComm.SerialPort; // Import oficial de jSerialComm
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.*;
import java.nio.file.Files;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;

/**
 *
 * @author oscar.lopez
 */
public class Comparador extends javax.swing.JFrame {
private File archivo1 = null; 
    private File archivo2 = null; 
    private config config = new config();
    private long ultimaModificacion = 0;
    private boolean monitoreando = false;

    // SERIAL
    private SerialPort cp210;
    private boolean pistonArriba = false;

public Comparador() {
    initComponents();
    this.setLocationRelativeTo(null);
    this.setResizable(false);
    
    // Configuraciones visuales previas
    txtmensaje.setFont(new Font("Monospaced", Font.PLAIN, 16));
    if (lblVersion != null) lblVersion.setText(VersionApp.getTextoVersion());
    setIconImage(getIconImage());

    // --- EL FIX PARA EL .EXE ---
    // Le damos 800ms para que el .exe se asiente en Windows antes de pedir el COM
    javax.swing.Timer timerInicio = new javax.swing.Timer(800, e -> {
        conectarESP32();
        ((javax.swing.Timer)e.getSource()).stop();
    });
    timerInicio.setRepeats(false);
    timerInicio.start();
}
    
        @Override
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/com.png"));
         
         
         return retValue;
    }

private void conectarESP32() {
    String puertoNombre = config.getPuertoCOM(); 
    
    cp210 = SerialPort.getCommPort(puertoNombre);
    cp210.setBaudRate(9600);
    cp210.setNumDataBits(8);
    cp210.setNumStopBits(SerialPort.ONE_STOP_BIT);
    cp210.setParity(SerialPort.NO_PARITY);
    cp210.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0);

    if (cp210.openPort()) {
        cp210.setDTR(); 
        cp210.setRTS();
        
        // --- AVISO DE CONEXIÓN EXITOSA ---
        java.awt.EventQueue.invokeLater(() -> {
            // Cambiamos el label de usuario para reflejar el estado
            jlUsuario.setText("SISTEMA LISTO");
            jlUsuario.setForeground(new Color(0, 153, 0)); // Verde éxito
            
            JOptionPane.showMessageDialog(this, 
                "✅ CONEXIÓN EXITOSA\n\nSe ha establecido comunicación con la ESP32\nen el puerto: " + puertoNombre, 
                "Hardware Listo", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        System.out.println("✅ Hardware conectado en " + puertoNombre);
        
    } else {
        // --- AVISO DE ERROR (El que ya teníamos) ---
        java.awt.EventQueue.invokeLater(() -> {
            String msg = "❌ FALLA DE CONEXIÓN SERIE\n\n" +
                         "El puerto [" + puertoNombre + "] no responde.\n" +
                         "Verifique conexión y archivo config.txt.";

            JOptionPane.showMessageDialog(this, msg, "Error Crítico de Hardware", JOptionPane.ERROR_MESSAGE);
            
            // Bloqueo de seguridad
            jbComparar.setEnabled(false);
            jbPiston.setEnabled(false);
            jbPiston1.setEnabled(false);
            
            jlUsuario.setText("SIN CONEXIÓN COM");
            jlUsuario.setForeground(Color.RED);
        });
    }
}

public void moverPiston(String accion) {
    if (cp210 != null && cp210.isOpen()) {
        // Enviamos el char puro 'U' o 'D'
        byte comando = (byte) (accion.equals("SUBIR") ? 'U' : 'D');
        byte[] buffer = { comando };
        
        cp210.writeBytes(buffer, 1); // Enviamos exactamente 1 byte
        System.out.println("Byte enviado: " + (char)comando);
    }
}

// --- VALIDACIÓN DE RUTAS ---
    private boolean esRutaValida(File seleccionado, String rutaPermitida) {
        try {
            return seleccionado.getCanonicalPath().startsWith(new File(rutaPermitida).getCanonicalPath());
        } catch (Exception e) { return false; }
    }

// --- LÓGICA DE COMPARACIÓN (ESTILO ORIGINAL) ---
private void ejecutarComparacionReal() {
    txtmensaje.setText("");
    StyledDocument doc = txtmensaje.getStyledDocument();
    Style styleG = txtmensaje.addStyle("Green", null);
    StyleConstants.setForeground(styleG, new Color(0, 153, 0));
    Style styleR = txtmensaje.addStyle("Red", null);
    StyleConstants.setForeground(styleR, Color.RED);

    try {
        List<String> lineasG = Files.readAllLines(archivo1.toPath());
        List<String> lineasS = Files.readAllLines(archivo2.toPath());
        boolean errorGrave = false;

        // ... (Tu lógica de índices XY y Wave se mantiene igual)
        
        // --- LOOP DE COMPARACIÓN ---
        // (Aquí va tu código actual de comparación de líneas...)

// Reemplaza tu método ejecutarComparacionReal en la parte final (donde libera el pistón)
if (!errorGrave) {
    doc.insertString(doc.getLength(), "✓ PARAMETRÍA CORRECTA. Pistón Liberado.", styleG);
    
    // REGISTRO DINÁMICO
    String detalle = String.format("COMPARACIÓN OK | Mod: %s | WO: %s | G: %s | S: %s", 
                     jtModelo.getText(), jtWo.getText(), archivo1.getName(), archivo2.getName());
    escribirLog(detalle);

    moverPiston("SUBIR");
    jbGolden.setEnabled(false);
    jbSelectiva.setEnabled(false);
    jlUsuario.setText("Esperando Login...");
    jlUsuario.setForeground(Color.BLACK);
    iniciarMonitoreo();
} else {
    escribirLog("COMPARACIÓN FALLIDA - Diferencias encontradas en Modelo: " + jtModelo.getText());
    moverPiston("BAJAR");
    resetearArchivos();
}
    } catch (Exception e) {
        escribirLog("ERROR CRÍTICO: " + e.getMessage());
    }
}

private boolean esIndice(int actual, int[] lista) {
        for (int x : lista) if (x == actual) return true;
        return false;
    }

    // --- REGISTRO LOG ---
    private void registrarEvento(String tecnico) {
        File fLog = new File(config.getPathLog());
        String log = String.format("[%s] | Tec: %s | Mod: %s | WO: %s | G: %s | S: %s",
            java.time.LocalDateTime.now().toString(), tecnico, jtModelo.getText(), jtWo.getText(), archivo1.getName(), archivo2.getName());
        try (PrintWriter pw = new PrintWriter(new FileWriter(fLog, true))) { pw.println(log); } catch (Exception e) {}
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jtModelo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jtWo = new javax.swing.JTextField();
        jbGolden = new javax.swing.JButton();
        jbSelectiva = new javax.swing.JButton();
        jbProcesos = new javax.swing.JButton();
        jbEquipos = new javax.swing.JButton();
        jbEditarU = new javax.swing.JButton();
        jbRegistros = new javax.swing.JButton();
        jbComparar = new javax.swing.JButton();
        jbCambio = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtmensaje = new javax.swing.JTextPane();
        jlUsuario = new javax.swing.JLabel();
        jbPiston = new javax.swing.JButton();
        lblVersion = new javax.swing.JLabel();
        jbPiston1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Comparador de Perfiles");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/inf.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jtModelo.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel1.setText("Modelo");

        jLabel2.setText("WO");

        jtWo.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jbGolden.setText("Archivo Golden");
        jbGolden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbGoldenActionPerformed(evt);
            }
        });

        jbSelectiva.setText("Archivo Selectiva");
        jbSelectiva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbSelectivaActionPerformed(evt);
            }
        });

        jbProcesos.setText("Agregar Procesos");
        jbProcesos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbProcesosActionPerformed(evt);
            }
        });

        jbEquipos.setText("Agregar Equipos");
        jbEquipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEquiposActionPerformed(evt);
            }
        });

        jbEditarU.setText("Editar Usuarios");
        jbEditarU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEditarUActionPerformed(evt);
            }
        });

        jbRegistros.setText("Registros");
        jbRegistros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbRegistrosActionPerformed(evt);
            }
        });

        jbComparar.setText("Comparar");
        jbComparar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCompararActionPerformed(evt);
            }
        });

        jbCambio.setText("Cambio de Modelo");
        jbCambio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCambioActionPerformed(evt);
            }
        });

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/p.png"))); // NOI18N

        jScrollPane2.setViewportView(txtmensaje);

        jbPiston.setText("Procesos");
        jbPiston.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbPistonActionPerformed(evt);
            }
        });

        lblVersion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jbPiston1.setText("Equipos");
        jbPiston1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbPiston1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(490, 490, 490)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel1)
                                .addGap(117, 117, 117)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49)
                                .addComponent(jtWo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jlUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(452, 452, 452)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblVersion, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbPiston))
                        .addGap(26, 26, 26))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jScrollPane2)
                .addGap(133, 133, 133))
            .addGroup(layout.createSequentialGroup()
                .addGap(631, 631, 631)
                .addComponent(jbComparar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbProcesos)
                .addGap(18, 18, 18)
                .addComponent(jbEquipos)
                .addGap(18, 18, 18)
                .addComponent(jbEditarU)
                .addGap(18, 18, 18)
                .addComponent(jbRegistros, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(441, 441, 441))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(181, 181, 181)
                .addComponent(jbGolden, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                .addComponent(jbCambio, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64)
                .addComponent(jbSelectiva, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(204, 204, 204))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(20, 20, 20)
                    .addComponent(jbPiston1)
                    .addContainerGap(1258, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 7, Short.MAX_VALUE)
                        .addComponent(jlUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtWo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblVersion, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jbComparar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbGolden)
                            .addComponent(jbSelectiva))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jbCambio)
                        .addGap(10, 10, 10)))
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbProcesos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbEquipos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbEditarU, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbRegistros, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbPiston))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addContainerGap(598, Short.MAX_VALUE)
                    .addComponent(jbPiston1)
                    .addGap(21, 21, 21)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JOptionPane.showMessageDialog(this, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" +"          Angel Estrada" + "\n" + "\n" +"                Contact" + "\n" + "Oscar.Lopez@plexus.com"+ "\n" +" Angel.Estrada@plexus.com");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jbGoldenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbGoldenActionPerformed
String rutaConfig = config.getPathGolden();
    
    // Normalización forzada: reemplaza diagonales y limpia espacios
    File root = new File(rutaConfig.replace("/", File.separator).replace("\\", File.separator));

    // DEPURACIÓN EN CONSOLA (Mira esto en el Output de NetBeans para ver el error real)
    System.out.println("Ruta leída: [" + rutaConfig + "]");
    System.out.println("Ruta absoluta: [" + root.getAbsolutePath() + "]");

    if (!root.exists()) {
        // Si falla, intentamos una última vez forzando la ruta manual 
        // por si el archivo config.txt tiene un formato extraño
        root = new File("C:\\Golden"); 
        
        if (!root.exists()) {
            JOptionPane.showMessageDialog(this, "ERROR CRÍTICO: La carpeta C:\\Golden no se encuentra en el disco local.");
            return;
        }
    }

    JFileChooser fc = new JFileChooser(root);
    fc.setDialogTitle("SELECCIONAR GOLDEN");
    
    // Impedir que el usuario cambie de directorio raíz (Ojito ahuevo)
    fc.setAcceptAllFileFilterUsed(false);
    fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Archivos CSV", "csv"));

    if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        File seleccionado = fc.getSelectedFile();
        
        // CANDADO: Validar que el archivo seleccionado esté dentro de C:\Golden
        if (esRutaValida(seleccionado, root.getAbsolutePath())) {
            archivo1 = seleccionado;
            jbGolden.setText("Golden: " + archivo1.getName());
        } else {
            JOptionPane.showMessageDialog(this, "¡SEGURIDAD! Solo puedes seleccionar archivos dentro de C:\\Golden", "Acceso Denegado", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_jbGoldenActionPerformed

    private void jbSelectivaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbSelectivaActionPerformed
// 1. Validación previa: No dejar avanzar si no hay Golden
    if (archivo1 == null) {
        JOptionPane.showMessageDialog(this, "Primero debe cargar el archivo GOLDEN.");
        return;
    }

    // 2. Obtener y limpiar la ruta de Selectiva del config
    String rutaConfig = config.getPathSelectiva();
    // Normalizamos diagonales y quitamos espacios invisibles
    File root = new File(rutaConfig.replace("/", File.separator).replace("\\", File.separator).trim());

    // 3. Forzar al buscador a iniciar en la ruta (si no existe, forzamos C:\Selectiva)
    if (!root.exists()) {
        root = new File("C:\\Selectiva");
        if (!root.exists()) {
            JOptionPane.showMessageDialog(this, "La ruta de Selectiva no existe en el disco.");
            return;
        }
    }

    JFileChooser fc = new JFileChooser(root);
    fc.setDialogTitle("SELECCIONAR SELECTIVA (Restringido a " + root.getPath() + ")");
    
    // Bloquear para que solo vean CSV
    fc.setAcceptAllFileFilterUsed(false);
    fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Archivos CSV", "csv"));

    if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        File seleccionado = fc.getSelectedFile();

        // 4. CANDADO DE SEGURIDAD: ¿Intentó retroceder?
        if (esRutaValida(seleccionado, root.getAbsolutePath())) {
            
            // 5. VALIDACIÓN DE NOMBRE: ¿Es el mismo modelo que el Golden?
            if (seleccionado.getName().equalsIgnoreCase(archivo1.getName())) {
                archivo2 = seleccionado;
                ultimaModificacion = archivo2.lastModified(); // Inicializamos el tiempo
                jbSelectiva.setText("Selectiva: " + archivo2.getName());
                txtmensaje.setText(""); // Limpiamos el área de texto
                iniciarMonitoreo(); // <--- AQUÍ ACTIVAS EL MONITOR
            } else {
                JOptionPane.showMessageDialog(this, 
                    "¡ERROR DE MODELO!\nEl archivo seleccionado debe llamarse igual al Golden:\n" + archivo1.getName(), 
                    "Archivo Incorrecto", JOptionPane.WARNING_MESSAGE);
            }
            
        } else {
            JOptionPane.showMessageDialog(this, 
                "¡ACCESO DENEGADO!\nNo tienes permiso para seleccionar archivos fuera de la carpeta Selectiva.", 
                "Seguridad", JOptionPane.ERROR_MESSAGE);
        }
      }
    }//GEN-LAST:event_jbSelectivaActionPerformed

    private void jbCompararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCompararActionPerformed
if (jtModelo.getText().trim().isEmpty() || jtWo.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Modelo y WO son obligatorios.");
        return;
    }
    if (archivo1 == null || archivo2 == null) {
        JOptionPane.showMessageDialog(this, "Cargue archivos Golden y Selectiva.");
        return;
    }

    JPasswordField passField = new JPasswordField();
    Object[] msg = { "Escanee Gafete de PROCESOS:", passField };
    if (JOptionPane.showConfirmDialog(this, msg, "Seguridad", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
        String pass = new String(passField.getPassword()).trim();
        if (validarUsuarioProcesos(pass)) {
            escribirLog("LOGIN EXITOSO - Iniciando comparación");
            ejecutarComparacionReal(); 
        } else {
            escribirLog("LOGIN FALLIDO - Intento de acceso con gafete: " + pass);
            JOptionPane.showMessageDialog(this, "Gafete no reconocido.");
        }
    }
    }//GEN-LAST:event_jbCompararActionPerformed

    private void jbProcesosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbProcesosActionPerformed
if (loginSuper()) { // Valida "ComparadorAzteca"
        Procesos p = new Procesos();
        p.setVisible(true);
        p.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    } else {
        JOptionPane.showMessageDialog(this, "Contraseña Incorrecta");
    }
    }//GEN-LAST:event_jbProcesosActionPerformed

    private void jbEquiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEquiposActionPerformed
if (loginSuper()) { // Valida "ComparadorAzteca"
        Equipos e = new Equipos();
        e.setVisible(true);
        e.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    } else {
        JOptionPane.showMessageDialog(this, "Contraseña Incorrecta");
    }
    }//GEN-LAST:event_jbEquiposActionPerformed

    private void jbEditarUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEditarUActionPerformed
if (loginSuper()) {
        String[] options = {"Procesos", "Equipos"};
        int sel = JOptionPane.showOptionDialog(this, "Elija la lista a editar:", "Configuración",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        
        if (sel != -1) {
            // Pasamos la ruta fija según la elección
            String ruta = (sel == 0) ? "C:\\Comparador\\procesos.txt" : "C:\\Comparador\\Equipos.txt";
            editar frameEdit = new editar(ruta, "ADMIN"); 
            frameEdit.setVisible(true);
        }
    }
    }//GEN-LAST:event_jbEditarUActionPerformed

    private void jbCambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCambioActionPerformed
    escribirLog("CAMBIO DE MODELO - Estación reseteada");
    resetearArchivos(); 
    jtModelo.setText(""); 
    jtWo.setText(""); 
    txtmensaje.setText("");
    jlUsuario.setText("Esperando Login...");
    
    // Reactivar botones si estaban bloqueados por un mantenimiento
    jbPiston.setEnabled(true);
    jbPiston1.setEnabled(true);
    
    moverPiston("BAJAR");
    }

    // --- MONITOR DE ARCHIVOS ---
private void iniciarMonitoreo() {
if (monitoreando) return;
    monitoreando = true;
    new Thread(() -> {
        while (monitoreando) {
            try {
                Thread.sleep(2000);
                if (archivo2 != null && archivo2.exists()) {
                    long m = archivo2.lastModified();
                    if (ultimaModificacion != 0 && m != ultimaModificacion) {
                        ultimaModificacion = m;
                        
                        // Si detectarCambioCritico() encuentra algo, ella misma baja el pistón 
                        // y muestra el mensaje específico, así que aquí no hace falta hacer más.
                        if (!detectarCambioCritico()) {
                            // Si el cambio NO fue crítico (ej. velocidad), solo refrescamos el visor
                            java.awt.EventQueue.invokeLater(() -> {
                                ejecutarComparacionReal();
                                System.out.println("Cambio no crítico detectado. El pistón sigue libre.");
                            });
                        }
                    }
                }
            } catch (Exception e) { }
        }
    }).start();
}

// Método de apoyo para filtrar los cambios que nos interesan
private boolean detectarCambioCritico() {
try {
        // Leemos las líneas actuales de ambos archivos para comparar
        List<String> lineasG = Files.readAllLines(archivo1.toPath());
        List<String> lineasS = Files.readAllLines(archivo2.toPath());
        
        // Iteramos a partir de la línea 3 (omitimos encabezados como en tu lógica original)
        for (int i = 3; i < Math.max(lineasG.size(), lineasS.size()); i++) {
            String[] gArr = (i < lineasG.size()) ? lineasG.get(i).split(";") : null;
            String[] sArr = (i < lineasS.size()) ? lineasS.get(i).split(";") : null;
            
            // Si falta alguna línea en uno de los dos, se considera cambio crítico
            if (gArr == null || sArr == null) {
                ejecutarAccionPorCambio("Diferencia en número de registros");
                return true;
            }

            String numSet = gArr[0]; // Identificador del Set de datos

            for (int j = 0; j < Math.max(gArr.length, sArr.length); j++) {
                String vG = (j < gArr.length) ? gArr[j].trim() : "";
                String vS = (j < sArr.length) ? sArr[j].trim() : "";
                
                // Si el valor es idéntico, saltamos al siguiente
                if (vG.equals(vS)) continue;

                String modulo = "";
                
                // --- VALIDACIÓN DE COORDENADAS X/Y (CRÍTICAS) ---
                if (j == 3 || j == 4) modulo = "FLUXER (EndPosition X/Y)";
                else if (j == 11 || j == 12) modulo = "SOLDADO 1 (EndPosition X/Y)";
                else if (j == 22 || j == 23) modulo = "SOLDADO 2 (EndPosition X/Y)";
                
                // --- VALIDACIÓN DE WAVE HEIGHT (TOLERANCIA 10.0) ---
                else if (j == 16 || j == 27 || j == 38) {
                    try {
                        double diff = Math.abs(Double.parseDouble(vG) - Double.parseDouble(vS));
                        if (diff > 10.0) {
                            modulo = (j == 16) ? "WAVE HEIGHT 1" : (j == 27) ? "WAVE HEIGHT 2" : "WAVE HEIGHT 3";
                        }
                    } catch (Exception e) { 
                        modulo = "WAVE HEIGHT (Error de Formato)"; 
                    }
                }

                // Si se detectó que el cambio pertenece a un módulo crítico
                if (!modulo.isEmpty()) {
                    ejecutarAccionPorCambio(modulo + " (Set " + numSet + ")");
                    return true;
                }
            }
        }
    } catch (IOException e) {
        System.err.println("Error en monitoreo: " + e.getMessage());
        return false; 
    }
    return false; // No se encontraron cambios críticos
    }//GEN-LAST:event_jbCambioActionPerformed

private void ejecutarAccionPorCambio(String razon) {
final String mensajeAlerta = "BLOQUEO AUTOMÁTICO - Cambio crítico detectado en: " + razon;
    
    moverPiston("BAJAR"); 
    escribirLog(mensajeAlerta); // Registro automático en el TXT del config
    
    java.awt.EventQueue.invokeLater(() -> {
        // Reset de interfaz para obligar a nueva carga
        archivo1 = null;
        archivo2 = null;
        jbGolden.setText("Archivo Golden");
        jbSelectiva.setText("Archivo Selectiva");
        jbGolden.setEnabled(true);
        jbSelectiva.setEnabled(true);
        jlUsuario.setText("Esperando Login...");
        monitoreando = false; 

        JOptionPane.showMessageDialog(this, 
            " ¡SEGURIDAD!\n" + mensajeAlerta + "\n\nSe requiere recargar archivos.", 
            "Cambio Detectado", JOptionPane.ERROR_MESSAGE);
    });
}
    // --- MÉTODO AUXILIAR PARA "DESCARGAR" ARCHIVOS ---
private void resetearArchivos() {
    archivo1 = null;
    archivo2 = null;
    jbGolden.setText("Archivo Golden");
    jbSelectiva.setText("Archivo Selectiva");
    jbGolden.setEnabled(true);     
    jbSelectiva.setEnabled(true);
    monitoreando = false;          
}

private boolean validarUsuarioProcesos(String gafete) {
    String ruta = config.getPathProcesos().trim().replace("\uFEFF", "");
    File f = new File(ruta);
    
    if (!f.exists()) return false;
    
    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String deen = desencriptar(linea); 
            String[] d = deen.split(",");
            if (d.length >= 3 && d[2].trim().equals(gafete.trim())) {
                jlUsuario.setText("Técnico: " + d[0].trim());
                jlUsuario.setForeground(new Color(0, 102, 204));
                // Registro inmediato del login exitoso
                escribirLog("LOGIN EXITOSO"); 
                return true;
            }
        }
    } catch (IOException e) { System.err.println(e.getMessage()); }
    return false;
}

private boolean validarUsuarioEquipos(String gafete) {
    String ruta = config.getPathEquipos().trim().replace("\uFEFF", "");
    File f = new File(ruta);
    if (!f.exists()) return false;

    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            if (linea.trim().isEmpty()) continue;

            String lineaLimpia = desencriptar(linea);
            String[] d = lineaLimpia.split(",");

            if (d.length >= 3 && d[2].trim().equals(gafete.trim())) {
                jlUsuario.setText("Equipos: " + d[0].trim());
                jlUsuario.setForeground(new Color(153, 0, 153));
                escribirLog("LOGIN EQUIPOS EXITOSO"); // Registro en Log
                return true;
            }
        }
    } catch (IOException e) { 
        System.err.println("Error lectura equipos: " + e.getMessage()); 
    }
    return false;
}

private boolean loginSuper() {
        JPasswordField pass = new JPasswordField();
        Object[] obj = {"Ingrese Password de Administrador:", pass};
        if (JOptionPane.showConfirmDialog(this, obj, "Seguridad de Nivel Superior", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            // AQUÍ ESTÁ TU CONTRASEÑA ORIGINAL
            return new String(pass.getPassword()).equals("ComparadorAzteca");
        }
        return false;
    }
    
    private void jbPistonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbPistonActionPerformed
JPasswordField pass = new JPasswordField();
    Object[] mensajeInput = {"Escanee Gafete de PROCESOS:", pass};

    if (JOptionPane.showConfirmDialog(this, mensajeInput, "Mantenimiento Procesos", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
        String gafeteIngresado = new String(pass.getPassword()).trim();
        
        if (validarUsuarioProcesos(gafeteIngresado)) {
            // El log de "LOGIN EXITOSO" ya se hizo dentro de validarUsuarioProcesos
            // Ahora registramos la acción específica del pistón
            escribirLog("ACCESO PISTÓN - Inicio Mantenimiento");

            jbPiston.setEnabled(false);
            jbPiston1.setEnabled(false);
            moverPiston("SUBIR");
            
            Timer timer = new Timer(120000, e -> {
                moverPiston("BAJAR");
                escribirLog("PISTÓN CERRADO - Tiempo agotado"); // Registro automático al cerrar
                jbPiston.setEnabled(true);
                jbPiston1.setEnabled(true);
                ((Timer)e.getSource()).stop();
            });
            timer.setRepeats(false);
            timer.start();
        } else {
            escribirLog("INTENTO FALLIDO - Gafete: " + gafeteIngresado);
        }
    }
    }//GEN-LAST:event_jbPistonActionPerformed

    private void jbRegistrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbRegistrosActionPerformed
// Limpiamos la ruta de caracteres invisibles antes de usarla
    String rutaLog = config.getPathLog().trim().replace("\uFEFF", "");
    File log = new File(rutaLog);
    
    if (!log.exists()) {
        JOptionPane.showMessageDialog(this, "No existe el archivo de registros aún.");
        return;
    }

    String[] columnas = {"Fecha y Hora", "Usuario", "Acceso / Acción"};
    DefaultTableModel modeloTabla = new DefaultTableModel(columnas, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };

    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(log), "UTF-8"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String lineaLimpia = desencriptar(linea); // <-- AQUÍ SE DESENCRIPTA EL LOG
            if (lineaLimpia.trim().isEmpty()) continue;
            
            String[] partes = lineaLimpia.split("\\|");
            if (partes.length >= 3) {
                String fecha = partes[0].replace("[", "").replace("]", "").trim();
                String usuario = partes[1].replace("Usuario:", "").trim();
                String accion = partes[2].replace("Acción:", "").trim();
                modeloTabla.insertRow(0, new Object[]{fecha, usuario, accion});
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }

    // --- CÓDIGO DE DISEÑO DE LA TABLA ---
    JTable tabla = new JTable(modeloTabla);
    tabla.setRowHeight(25);
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
    for (int i = 0; i < tabla.getColumnCount(); i++) {
        tabla.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }
    ((DefaultTableCellRenderer)tabla.getTableHeader().getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
    
    tabla.getColumnModel().getColumn(0).setPreferredWidth(140);
    tabla.getColumnModel().getColumn(0).setMaxWidth(160);
    tabla.getColumnModel().getColumn(1).setPreferredWidth(90);
    tabla.getColumnModel().getColumn(1).setMaxWidth(110);
    
    JScrollPane scrollPane = new JScrollPane(tabla);
    scrollPane.setPreferredSize(new Dimension(950, 500));
    JOptionPane.showMessageDialog(this, scrollPane, "Historial Protegido", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_jbRegistrosActionPerformed

    private void jbPiston1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbPiston1ActionPerformed
JPasswordField pass = new JPasswordField();
    Object[] prompt = {"Escanee Gafete de Equipos:", pass};

    if (JOptionPane.showConfirmDialog(this, prompt, "Mantenimiento Equipos", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
        String gafete = new String(pass.getPassword()).trim();
        
        if (validarUsuarioEquipos(gafete)) {
            escribirLog("ACCESO PISTÓN - Mantenimiento Equipos (2 min)");
            
            jbPiston.setEnabled(false);
            jbPiston1.setEnabled(false);
            moverPiston("SUBIR");
            
            Timer timer = new Timer(120000, e -> {
                moverPiston("BAJAR");
                escribirLog("PISTÓN CERRADO - Fin tiempo Equipos");
                jbPiston.setEnabled(true);
                jbPiston1.setEnabled(true);
                ((Timer)e.getSource()).stop();
            });
            timer.setRepeats(false);
            timer.start();
            
            JOptionPane.showMessageDialog(this, "Acceso concedido.\nPistón liberado por 2 minutos.");
        } else {
            escribirLog("INTENTO FALLIDO EQUIPOS - Gafete: " + gafete);
            JOptionPane.showMessageDialog(this, "GAFETE NO RECONOCIDO", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_jbPiston1ActionPerformed

private void escribirLog(String accion) {
    // CORRECCIÓN: Usar la ruta del config, no la ruta fija "C:\\..."
    String ruta = config.getPathLog().trim().replace("\uFEFF", "");
    File archivoLog = new File(ruta);
    
    String fechaHora = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    // Obtener usuario del label
    String usuario = jlUsuario.getText().contains(":") ? jlUsuario.getText().split(":")[1].trim() : "Sistema";
    
    String lineaPlana = "[" + fechaHora + "] | Usuario: " + usuario + " | Acción: " + accion;
    String lineaEncriptada = encriptar(lineaPlana);
    
    // Usamos BufferedWriter para forzar la escritura inmediata
    try (FileWriter fw = new FileWriter(archivoLog, true);
         BufferedWriter bw = new BufferedWriter(fw);
         PrintWriter out = new PrintWriter(bw)) {
        out.println(lineaEncriptada);
        System.out.println("✅ Log registrado en: " + ruta);
    } catch (IOException e) { 
        System.err.println("❌ Error al escribir log: " + e.getMessage()); 
    }
}

// Importar java.util.Base64 arriba en la clase
private String encriptar(String texto) {
    try {
        return java.util.Base64.getEncoder().encodeToString(texto.getBytes("UTF-8"));
    } catch (Exception e) { return texto; }
}

private String desencriptar(String textoEncriptado) {
    try {
        // El trim es fundamental aquí
        byte[] decodedBytes = java.util.Base64.getDecoder().decode(textoEncriptado.trim());
        return new String(decodedBytes, "UTF-8");
    } catch (Exception e) {
        // Si no es Base64, devolvemos el original para no romper el programa
        return textoEncriptado; 
    }
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Comparador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Comparador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Comparador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Comparador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Comparador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton jbCambio;
    private javax.swing.JButton jbComparar;
    private javax.swing.JButton jbEditarU;
    private javax.swing.JButton jbEquipos;
    private javax.swing.JButton jbGolden;
    private javax.swing.JButton jbPiston;
    private javax.swing.JButton jbPiston1;
    private javax.swing.JButton jbProcesos;
    private javax.swing.JButton jbRegistros;
    private javax.swing.JButton jbSelectiva;
    private javax.swing.JLabel jlUsuario;
    private javax.swing.JTextField jtModelo;
    private javax.swing.JTextField jtWo;
    private javax.swing.JLabel lblVersion;
    private javax.swing.JTextPane txtmensaje;
    // End of variables declaration//GEN-END:variables
}
