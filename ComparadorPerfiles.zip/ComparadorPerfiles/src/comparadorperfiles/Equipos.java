/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparadorperfiles;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.util.Base64; // Librería para encriptar/desencriptar

/**
 *
 * @author oscar.lopez
 */
public class Equipos extends javax.swing.JFrame {

    private config config = new config();
    DefaultTableModel modeloTabla;
    
    public Equipos() {
initComponents();
        this.setLocationRelativeTo(null);
        prepararTabla();
        cargarDatosDesdeArchivo(); // Carga y desencripta

        setIconImage(getIconImage());
        this.setResizable(false);

        // --- REGISTRO EN EL LOG ---
        registrarAccion("CONSULTA: Abrió gestión de Técnicos de Equipos.");

        // --- RESTRICCIÓN DE TECLADO ---
        jtNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!(Character.isDigit(c)) || jtNumero.getText().length() >= 6) {
                    evt.consume();
                }
            }
        });

        // --- LOGICA DEL CHECKBOX REINSTALADA ---
        chkVerGafete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                // Forzamos a la tabla a redibujarse para que el Renderer 
                // decida si muestra asteriscos o el número real
                jTable1.repaint(); 
            }
        });
    }
    
            @Override
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/proteger (1) (1).png"));
         
         
         return retValue;
    }
    
    // --- MÉTODOS DE ENCRIPTACIÓN BASE64 ---
    private String encriptar(String texto) {
        return Base64.getEncoder().encodeToString(texto.getBytes());
    }

private String desencriptar(String textoEncriptado) {
    if (textoEncriptado == null || textoEncriptado.trim().isEmpty()) return "";
    try {
        // .trim() y limpieza de caracteres invisibles BOM
        String limpio = textoEncriptado.trim().replace("\uFEFF", "");
        byte[] decodedBytes = java.util.Base64.getDecoder().decode(limpio);
        return new String(decodedBytes, "UTF-8");
    } catch (Exception e) {
        // Si no es Base64 (texto plano viejo), devuelve el original
        return textoEncriptado; 
    }
}
    
private void prepararTabla() {
        modeloTabla = new DefaultTableModel(
                new Object[]{"Nombre", "# Empleado", "Gafete"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        jTable1.setModel(modeloTabla);

        // Renderer con lógica de Checkbox y Centrado
        DefaultTableCellRenderer centroRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {

                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);

                // Si es la columna 2 (Gafete) y el Checkbox NO está seleccionado
                if (column == 2 && !chkVerGafete.isSelected()) {
                    setText("****");
                }
                return this;
            }
        };

        for (int i = 0; i < jTable1.getColumnCount(); i++) {
            jTable1.getColumnModel().getColumn(i).setCellRenderer(centroRenderer);
        }
    }

// EVENTO DEL CHECKBOX
    private void chkVerGafeteActionPerformed(java.awt.event.ActionEvent evt) {                                             
        jTable1.repaint(); // Refresca la tabla para mostrar/ocultar asteriscos
    }
    
private void cargarDatosDesdeArchivo() {
    modeloTabla.setRowCount(0);
    // Limpiamos la ruta de caracteres invisibles (\uFEFF)
    String ruta = config.getPathEquipos().trim().replace("\uFEFF", "");
    File archivo = new File(ruta); 
    
    if (!archivo.exists()) {
        System.err.println("Archivo no encontrado en: " + ruta);
        return;
    }

    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(archivo), "UTF-8"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            if (!linea.trim().isEmpty()) {
                // 1. Desencriptar la línea completa
                String deen = desencriptar(linea);
                if (!deen.isEmpty()) {
                    // 2. Partir por comas y agregar a la tabla
                    modeloTabla.addRow(deen.split(","));
                }
            }
        }
    } catch (IOException e) {
        System.err.println("Error al cargar equipos: " + e.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtNombre = new javax.swing.JTextField();
        jtNumero = new javax.swing.JTextField();
        jpGafete = new javax.swing.JPasswordField();
        jbAgregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        chkVerGafete = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registro Personal de Equipos");

        jLabel1.setText("Nombre");

        jLabel2.setText("# de empleado");

        jLabel3.setText("Gafete");

        jtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jtNumero.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jpGafete.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jbAgregar.setText("Agregar");
        jbAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAgregarActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setText("Esta es información personal, no compartas los datos con nadie.");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/inf.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        chkVerGafete.setText("Ver Gafetes");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(chkVerGafete))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(69, 69, 69)
                                        .addComponent(jtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel1)
                                        .addGap(69, 69, 69)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jbAgregar)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(8, 8, 8)
                                                .addComponent(jLabel2)))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jpGafete, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(27, 27, 27)
                                                .addComponent(jLabel3)))))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpGafete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(5, 5, 5)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel1)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbAgregar)
                    .addComponent(chkVerGafete, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAgregarActionPerformed
String nombre = jtNombre.getText().trim();
    String numero = jtNumero.getText().trim();
    String gafete = new String(jpGafete.getPassword()).trim();

    if (nombre.isEmpty() || numero.isEmpty() || gafete.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
        return;
    }

    String dataPlana = nombre + "," + numero + "," + gafete;
    String dataEncriptada = encriptar(dataPlana);

    // Ruta limpia del config
    String rutaEquipos = config.getPathEquipos().trim().replace("\uFEFF", "");

    try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(rutaEquipos, true), "UTF-8"))) {
        pw.println(dataEncriptada);
        
        modeloTabla.addRow(new Object[]{nombre, numero, gafete});
        registrarAccion("ALTA DE USUARIO EQUIPOS: " + nombre);

        jtNombre.setText("");
        jtNumero.setText("");
        jpGafete.setText("");
        JOptionPane.showMessageDialog(this, "✅ Registro de Equipos guardado.");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al escribir: " + e.getMessage());
    }
    }//GEN-LAST:event_jbAgregarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JOptionPane.showMessageDialog(this, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" +"          Angel Estrada" + "\n" + "\n" +"                Contact" + "\n" + "Oscar.Lopez@plexus.com"+ "\n" +" Angel.Estrada@plexus.com");
    }//GEN-LAST:event_jButton2ActionPerformed

private void registrarAccion(String detalle) {
    // Limpieza de ruta del log
    String rutaLog = config.getPathLog().trim().replace("\uFEFF", "");
    File archivoLog = new File(rutaLog);
    
    String fechaHora = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    String lineaLog = String.format("[%s] | Usuario: ADMIN/EQUIPOS | Acción: %s", fechaHora, detalle);
    
    // Encriptamos la línea del log
    String encriptado = encriptarLog(lineaLog); 

    try (PrintWriter pw = new PrintWriter(new FileWriter(archivoLog, true))) {
        pw.println(encriptado);
    } catch (IOException e) {
        System.err.println("Error escribiendo log desde Equipos: " + e.getMessage());
    }
}

private String encriptarLog(String texto) {
    try {
        return java.util.Base64.getEncoder().encodeToString(texto.getBytes("UTF-8"));
    } catch (Exception e) { return texto; }
}


    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Equipos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Equipos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Equipos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Equipos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Equipos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox chkVerGafete;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbAgregar;
    private javax.swing.JPasswordField jpGafete;
    private javax.swing.JTextField jtNombre;
    private javax.swing.JTextField jtNumero;
    // End of variables declaration//GEN-END:variables
}
