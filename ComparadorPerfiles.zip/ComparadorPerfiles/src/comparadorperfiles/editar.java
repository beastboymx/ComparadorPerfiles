/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparadorperfiles;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Base64;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author oscar.lopez
 */
public class editar extends javax.swing.JFrame {

    private String rutaArchivo; 
    private String usuarioAdmin; 
    private config config = new config(); 
    private DefaultTableModel modelo; 
    
    public editar(String ruta, String admin) {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        this.rutaArchivo = ruta;
        this.usuarioAdmin = admin; // <-- Cambiado de adminNombre a admin para que coincida        
        this.setLocationRelativeTo(null);
        this.setTitle("Administración de Usuarios: " + new File(ruta).getName());
        setIconImage(getIconImage());
        this.setResizable(false);

        prepararTabla();
        cargarDatosDesdeArchivo(); 

        registrarAccion("ACCESO: Entró al modo de edición de base de datos.");

        // Restricción de 6 dígitos
        jtNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!(Character.isDigit(c)) || jtNumero.getText().length() >= 6) {
                    evt.consume();
                }
            }
        });

        // Listener de la tabla
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int fila = jTable1.getSelectedRow();
                if (fila != -1) {
                    jtNombre.setText(modelo.getValueAt(fila, 0).toString());
                    jtNumero.setText(modelo.getValueAt(fila, 1).toString());
                    jpGafete.setText(modelo.getValueAt(fila, 2).toString());
                }
            }
        });
    }
    
// --- MÉTODOS DE SEGURIDAD ---
    private String encriptar(String texto) {
        try {
            return Base64.getEncoder().encodeToString(texto.getBytes("UTF-8"));
        } catch (Exception e) { return texto; }
    }

private String desencriptar(String textoEncriptado) {
    if (textoEncriptado == null || textoEncriptado.trim().isEmpty()) return "";
    try {
        // .trim() y limpieza del carácter invisible BOM (\uFEFF)
        String limpio = textoEncriptado.trim().replace("\uFEFF", "");
        byte[] decodedBytes = Base64.getDecoder().decode(limpio);
        return new String(decodedBytes, "UTF-8");
    } catch (Exception e) {
        // Si no es Base64, devolvemos vacío para no llenar la tabla de basura
        return ""; 
    }
}
    
                    @Override
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/proteger (1) (1).png"));
         
         
         return retValue;
    }
    
private void prepararTabla() {
        modelo = new DefaultTableModel(new Object[]{"Nombre", "# Empleado", "Gafete"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        jTable1.setModel(modelo);

        DefaultTableCellRenderer centro = new DefaultTableCellRenderer();
        centro.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < jTable1.getColumnCount(); i++) {
            jTable1.getColumnModel().getColumn(i).setCellRenderer(centro);
        }
    }

private void cargarDatosDesdeArchivo() {
    modelo.setRowCount(0);
    // Limpiamos la ruta por si trae caracteres invisibles del config
    String rutaLimpia = rutaArchivo.trim().replace("\uFEFF", "");
    File f = new File(rutaLimpia);
    
    if (!f.exists()) {
        System.err.println("Editar: Archivo no encontrado en " + rutaLimpia);
        return;
    }
    
    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            if (!linea.trim().isEmpty()) {
                String deen = desencriptar(linea);
                if (!deen.isEmpty()) {
                    modelo.addRow(deen.split(","));
                }
            }
        }
    } catch (Exception e) { 
        System.err.println("Error al cargar en Editar: " + e.getMessage()); 
    }
}

private void actualizarArchivoTxt() {
    String rutaLimpia = rutaArchivo.trim().replace("\uFEFF", "");
    try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(rutaLimpia), "UTF-8"))) {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            String lineaPlana = modelo.getValueAt(i, 0) + "," +
                               modelo.getValueAt(i, 1) + "," +
                               modelo.getValueAt(i, 2);
            pw.println(encriptar(lineaPlana));
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al guardar cambios en el archivo.");
    }
}
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtNombre = new javax.swing.JTextField();
        jtNumero = new javax.swing.JTextField();
        jpGafete = new javax.swing.JPasswordField();
        jbEditar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jbEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nombre");

        jLabel2.setText("# de empleado");

        jLabel3.setText("Gafete");

        jtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jtNumero.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jpGafete.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jbEditar.setText("Editar");
        jbEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEditarActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setText("Esta es información personal, no compartas los datos con nadie.");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/inf.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jbEliminar.setText("Eliminar");
        jbEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(jLabel1)))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(19, 19, 19)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jpGafete, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbEditar)
                .addGap(18, 18, 18)
                .addComponent(jbEliminar)
                .addGap(220, 220, 220))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpGafete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbEditar)
                    .addComponent(jbEliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEliminarActionPerformed
        int fila = jTable1.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un registro.");
            return;
        }

        String nombreEliminado = modelo.getValueAt(fila, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar a " + nombreEliminado + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            modelo.removeRow(fila);
            actualizarArchivoTxt();
            registrarAccion("ELIMINÓ AL USUARIO: " + nombreEliminado);
            limpiarCampos();
            JOptionPane.showMessageDialog(this, "Registro eliminado.");
        }
    }//GEN-LAST:event_jbEliminarActionPerformed

    private void jbEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEditarActionPerformed
int fila = jTable1.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila.");
            return;
        }

        String nombreEditado = jtNombre.getText().trim();
        modelo.setValueAt(nombreEditado, fila, 0);
        modelo.setValueAt(jtNumero.getText().trim(), fila, 1);
        modelo.setValueAt(new String(jpGafete.getPassword()).trim(), fila, 2);

        actualizarArchivoTxt();
        registrarAccion("EDITÓ AL USUARIO: " + nombreEditado);

        limpiarCampos();
        JOptionPane.showMessageDialog(this, "Registro actualizado.");
    }//GEN-LAST:event_jbEditarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JOptionPane.showMessageDialog(this, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" +"          Angel Estrada" + "\n" + "\n" +"                Contact" + "\n" + "Oscar.Lopez@plexus.com"+ "\n" +" Angel.Estrada@plexus.com");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void limpiarCampos() {
        jtNombre.setText("");
        jtNumero.setText("");
        jpGafete.setText("");
        jTable1.clearSelection();
    }
    
private void registrarAccion(String detalle) {
    // Obtenemos la ruta del log desde el config y la limpiamos
    String rutaLog = config.getPathLog().trim().replace("\uFEFF", "");
    File archivoLog = new File(rutaLog);
    
    String fechaHora = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    String base = new File(rutaArchivo).getName().toUpperCase();
    
    String lineaLog = String.format("[%s] | Usuario: %s | Acción: (%s) %s", fechaHora, usuarioAdmin, base, detalle);
    String encriptado = encriptar(lineaLog);

    try (FileWriter fw = new FileWriter(archivoLog, true);
         BufferedWriter bw = new BufferedWriter(fw);
         PrintWriter pw = new PrintWriter(bw)) {
        pw.println(encriptado);
    } catch (IOException e) {
        System.err.println("Error en log de Editar: " + e.getMessage());
    }
}
    
    
    /**
     * @param args the command line arguments
     */
public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            // Nota: El archivo config ya maneja las rutas, esto es solo para que el main no marque error
            new editar("C:\\Comparador\\procesos.txt", "ADMIN").setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbEditar;
    private javax.swing.JButton jbEliminar;
    private javax.swing.JPasswordField jpGafete;
    private javax.swing.JTextField jtNombre;
    private javax.swing.JTextField jtNumero;
    // End of variables declaration//GEN-END:variables
}
