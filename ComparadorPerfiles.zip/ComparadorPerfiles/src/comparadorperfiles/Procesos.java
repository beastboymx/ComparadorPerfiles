/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparadorperfiles;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Base64;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author oscar.lopez
 */
public class Procesos extends javax.swing.JFrame {
    
    private config config = new config();
    DefaultTableModel modeloTabla;
    
    public Procesos() {
initComponents();
        this.setLocationRelativeTo(null);
        prepararTabla();
        cargarDatosDesdeArchivo(); // Carga y desencripta automáticamente

        setIconImage(getIconImage());
        this.setResizable(false);

        // --- REGISTRO EN EL LOG ---
        registrarAccion("CONSULTA: Abrió lista de gestión de Técnicos de Procesos.");

        // --- RESTRICCIÓN DE TECLADO (6 dígitos) ---
        jtNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!(Character.isDigit(c)) || jtNumero.getText().length() >= 6) {
                    evt.consume();
                }
            }
        });

        // --- ACCIÓN PARA EL CHECKBOX ---
        chkVerGafete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTable1.repaint(); // Refresca para mostrar/ocultar asteriscos
            }
        });
    }
    
    // --- MÉTODOS DE ENCRIPTACIÓN BASE64 ---
    private String encriptar(String texto) {
        return Base64.getEncoder().encodeToString(texto.getBytes());
    }

private String desencriptar(String textoEncriptado) {
    if (textoEncriptado == null || textoEncriptado.trim().isEmpty()) return "";
    try {
        // Limpieza de espacios y del carácter invisible BOM (\uFEFF)
        String limpio = textoEncriptado.trim().replace("\uFEFF", "");
        byte[] decodedBytes = java.util.Base64.getDecoder().decode(limpio);
        return new String(decodedBytes, "UTF-8");
    } catch (Exception e) {
        // Si no es Base64 (texto viejo), devuelve el original
        return textoEncriptado; 
    }
}
    
                @Override
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/proteger (1) (1).png"));
         
         
         return retValue;
    }
    
private void prepararTabla() {
        modeloTabla = new DefaultTableModel(
                new Object[]{"Nombre", "# Empleado", "Gafete"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        jTable1.setModel(modeloTabla);

        // Renderer para centrado y lógica de asteriscos
        DefaultTableCellRenderer centroRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {

                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);

                // Si es columna de Gafete y el checkbox NO está marcado
                if (column == 2 && !chkVerGafete.isSelected()) {
                    setText("****");
                }
                return this;
            }
        };

        for (int i = 0; i < jTable1.getColumnCount(); i++) {
            jTable1.getColumnModel().getColumn(i).setCellRenderer(centroRenderer);
        }

        ((DefaultTableCellRenderer) jTable1.getTableHeader().getDefaultRenderer())
                .setHorizontalAlignment(SwingConstants.CENTER);
    }

// EVENTO DEL CHECKBOX
    private void chkVerGafeteActionPerformed(java.awt.event.ActionEvent evt) {                                             
        jTable1.repaint(); // Refresca la tabla para mostrar/ocultar asteriscos
    }
    
private void cargarDatosDesdeArchivo() {
    modeloTabla.setRowCount(0);
    // Limpieza profunda de la ruta obtenida del config
    String ruta = config.getPathProcesos().trim().replace("\uFEFF", "");
    File archivo = new File(ruta); 
    
    if (!archivo.exists()) {
        System.err.println("Archivo de procesos no encontrado en: " + ruta);
        return;
    }

    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(archivo), "UTF-8"))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            if (!linea.trim().isEmpty()) {
                // Desencriptar antes de mostrar en la tabla
                String lineaLimpia = desencriptar(linea);
                if(!lineaLimpia.isEmpty()){
                    modeloTabla.addRow(lineaLimpia.split(","));
                }
            }
        }
    } catch (IOException e) {
        System.err.println("Error al cargar procesos: " + e.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtNombre = new javax.swing.JTextField();
        jtNumero = new javax.swing.JTextField();
        jpGafete = new javax.swing.JPasswordField();
        jbAgregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        chkVerGafete = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registro Personal de Procesos");

        jLabel1.setText("Nombre");

        jLabel2.setText("# de empleado");

        jLabel3.setText("Gafete");

        jtNombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jtNumero.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jpGafete.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jbAgregar.setText("Agregar");
        jbAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAgregarActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setText("Esta es información personal, no compartas los datos con nadie.");

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/inf.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        chkVerGafete.setText("Ver Gafetes");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jLabel1)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(jLabel2)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jpGafete, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(41, 41, 41)
                                        .addComponent(jLabel3)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jbAgregar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(chkVerGafete))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 8, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpGafete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbAgregar)
                    .addComponent(chkVerGafete, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAgregarActionPerformed
String nombre = jtNombre.getText().trim();
    String numero = jtNumero.getText().trim();
    String gafete = new String(jpGafete.getPassword()).trim();

    if (nombre.isEmpty() || numero.isEmpty() || gafete.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
        return;
    }

    if (numero.length() != 6) {
        JOptionPane.showMessageDialog(this, "El número de empleado debe ser de 6 dígitos.");
        return;
    }

    String dataPlana = nombre + "," + numero + "," + gafete;
    String dataEncriptada = encriptar(dataPlana);

    // Obtener ruta limpia
    String rutaProcesos = config.getPathProcesos().trim().replace("\uFEFF", "");

    try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(rutaProcesos, true), "UTF-8"))) {
        pw.println(dataEncriptada);
        
        modeloTabla.addRow(new Object[]{nombre, numero, gafete});
        registrarAccion("ALTA DE USUARIO PROCESOS: " + nombre);

        jtNombre.setText("");
        jtNumero.setText("");
        jpGafete.setText("");
        JOptionPane.showMessageDialog(this, "✅ Registro de Procesos guardado con éxito.");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al escribir: " + e.getMessage());
    }
    }//GEN-LAST:event_jbAgregarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JOptionPane.showMessageDialog(this, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" +"          Angel Estrada" + "\n" + "\n" +"                Contact" + "\n" + "Oscar.Lopez@plexus.com"+ "\n" +" Angel.Estrada@plexus.com");
    }//GEN-LAST:event_jButton2ActionPerformed

    
private void registrarAccion(String detalle) {
    String rutaLog = config.getPathLog().trim().replace("\uFEFF", "");
    File archivoLog = new File(rutaLog);
    
    String fechaHora = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    String lineaLog = String.format("[%s] | Usuario: ADMIN/PROCESOS | Acción: %s", fechaHora, detalle);
    
    String encriptado = encriptarLog(lineaLog); 

    try (FileWriter fw = new FileWriter(archivoLog, true);
         BufferedWriter bw = new BufferedWriter(fw);
         PrintWriter pw = new PrintWriter(bw)) {
        pw.println(encriptado);
    } catch (IOException e) {
        System.err.println("Error escribiendo log desde Procesos: " + e.getMessage());
    }
}
    
    // 1. Agrega los métodos de encriptación (dentro de la clase Procesos)
private String encriptarLog(String texto) {
    try {
        return java.util.Base64.getEncoder().encodeToString(texto.getBytes("UTF-8"));
    } catch (Exception e) { return texto; }
}
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Procesos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Procesos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Procesos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Procesos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Procesos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox chkVerGafete;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbAgregar;
    private javax.swing.JPasswordField jpGafete;
    private javax.swing.JTextField jtNombre;
    private javax.swing.JTextField jtNumero;
    // End of variables declaration//GEN-END:variables
}
