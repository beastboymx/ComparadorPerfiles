package comparadorperfiles;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class config {
    private Properties props = new Properties();
    private final String pathConfig = "C:\\Comparador\\config.txt";

    public config() {
        try {
            File f = new File(pathConfig);
            if (f.exists()) {
                FileInputStream fis = new FileInputStream(f);
                props.load(fis);
                fis.close();
            }
        } catch (Exception e) {
            System.err.println("Error cargando configuración: " + e.getMessage());
        }
    }

    private String limpiarRuta(String llave, String defecto) {
        String ruta = props.getProperty(llave, defecto).trim();
        return ruta.replace("\"", "");
    }

    public String getPathGolden() { return limpiarRuta("RUTA_GOLDEN", "C:\\Golden"); }
    public String getPathSelectiva() { return limpiarRuta("RUTA_SELECTIVA", "C:\\Selectiva"); }
    
    // Rutas para los archivos de usuarios
    public String getPathProcesos() { return "C:\\Comparador\\procesos.txt"; }
    public String getPathEquipos() { return "C:\\Comparador\\Equipos.txt"; }
    public String getPathLog() {return "C:\\Comparador\\registros_comparacion.txt";}
}