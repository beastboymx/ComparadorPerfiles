package comparadorperfiles;

import java.io.*;
import java.util.Properties;

public class config {
    private Properties props = new Properties();
    private final String pathConfig = "C:\\Comparador\\config.txt";

    public config() {
        File f = new File(pathConfig);
        if (!f.exists()) return;

        // Leemos el archivo manualmente para evitar que Properties borre las diagonales \
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                // Ignorar comentarios o líneas vacías
                if (linea.isEmpty() || linea.startsWith("#")) continue;
                
                // Dividir solo en el primer signo '='
                String[] partes = linea.split("=", 2);
                if (partes.length == 2) {
                    String llave = partes[0].trim();
                    String valor = partes[1].trim();
                    // Limpieza profunda de caracteres invisibles
                    valor = valor.replace("\uFEFF", "").replace("\"", "");
                    props.put(llave, valor);
                }
            }
        } catch (IOException e) {
            System.err.println("Error cargando configuración: " + e.getMessage());
        }
    }

    private String obtenerValor(String llave, String defecto) {
        return props.getProperty(llave, defecto);
    }

    public String getPathGolden() { return obtenerValor("RUTA_GOLDEN", "C:\\Golden"); }
    public String getPathSelectiva() { return obtenerValor("RUTA_SELECTIVA", "C:\\Selectiva"); }
    public String getPuertoCOM() { return obtenerValor("PUERTO_COM", "COM8"); }
    public String getPathProcesos() { return obtenerValor("RUTA_PROCESOS", "C:\\Comparador\\procesos.txt"); }
    public String getPathEquipos() { return obtenerValor("RUTA_EQUIPOS", "C:\\Comparador\\Equipos.txt"); }
    public String getPathLog() { return obtenerValor("RUTA_LOG", "C:\\Comparador\\registros_comparacion.txt"); }
}