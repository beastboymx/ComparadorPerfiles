package comparadorperfiles;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author oscar.lopez
 */
public class VersionApp {
    // CAMBIA ESTA CONSTANTE PARA ACTUALIZACIONES (ej. "v1.1.0", "v2.0.0")
    public static final String VERSION = "V1.0.0";
    

    public static String getTextoVersion() {
        return "Versión " + VERSION;
    }
    
    // Opcional: Método para solo la versión (si quieres algo más corto)
    public static String getVersionSimple() {
        return "v" + VERSION;
    }
}
